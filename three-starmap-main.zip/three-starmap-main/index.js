import { Stars } from "./src/Stars";

export default Stars;
